# ns2Extended
Here we are going to extend ns2's functionality by including the available ns2 extentions.
